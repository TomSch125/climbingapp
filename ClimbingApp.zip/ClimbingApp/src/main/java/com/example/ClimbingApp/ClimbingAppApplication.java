package com.example.ClimbingApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClimbingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClimbingAppApplication.class, args);
	}

}
